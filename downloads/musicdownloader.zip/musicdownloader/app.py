import customtkinter as ctk
import os
import threading
import yt_dlp
from tkinter import filedialog, messagebox
import sys
import shutil

# --- Configuration & Theme ---
ctk.set_appearance_mode("Dark")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"

class ConsoleRedirector:
    """A helper class to redirect stdout/stderr to a text widget."""
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, str_val):
        self.text_widget.configure(state="normal")
        self.text_widget.insert("end", str_val)
        self.text_widget.see("end")  # Auto-scroll to the bottom
        self.text_widget.configure(state="disabled")

    def flush(self):
        pass

class MusicDownloaderApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window Setup
        self.title("High Def Audio Downloader")
        self.geometry("700x550")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)  # Make console row expandable

        # 1. Header Section
        self.header_frame = ctk.CTkFrame(self, corner_radius=10)
        self.header_frame.grid(row=0, column=0, padx=20, pady=20, sticky="ew")
        
        self.label_title = ctk.CTkLabel(
            self.header_frame, 
            text="High Definition Audio Downloader", 
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.label_title.pack(pady=10)

        # 2. Input Section
        self.input_frame = ctk.CTkFrame(self)
        self.input_frame.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        self.input_frame.grid_columnconfigure(1, weight=1)

        # URL Input
        self.label_url = ctk.CTkLabel(self.input_frame, text="YouTube URL:")
        self.label_url.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        self.entry_url = ctk.CTkEntry(self.input_frame, placeholder_text="Paste link here...")
        self.entry_url.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

        # Folder Selection
        self.label_folder = ctk.CTkLabel(self.input_frame, text="Save Folder:")
        self.label_folder.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        
        self.entry_folder = ctk.CTkEntry(self.input_frame, placeholder_text="Select download folder...")
        self.entry_folder.insert(0, os.path.join(os.getcwd(), "downloads")) # Default
        self.entry_folder.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        self.btn_browse = ctk.CTkButton(self.input_frame, text="Browse", width=80, command=self.browse_folder)
        self.btn_browse.grid(row=1, column=2, padx=10, pady=10)

        # 3. Action Section
        self.btn_download = ctk.CTkButton(
            self, 
            text="Start Download", 
            font=ctk.CTkFont(size=16, weight="bold"),
            height=40,
            fg_color="#1f538d", # Custom accent color
            hover_color="#14375e",
            command=self.start_download_thread
        )
        self.btn_download.grid(row=2, column=0, padx=20, pady=(0, 10), sticky="ew")

        # Progress Bar
        self.progress_bar = ctk.CTkProgressBar(self)
        self.progress_bar.grid(row=3, column=0, padx=20, pady=(0, 20), sticky="ew")
        self.progress_bar.set(0)

        # 4. Console Log Section
        self.console_frame = ctk.CTkFrame(self)
        self.console_frame.grid(row=4, column=0, padx=20, pady=(0, 20), sticky="nsew")
        
        self.label_console = ctk.CTkLabel(self.console_frame, text="Console Logs:", anchor="w")
        self.label_console.pack(fill="x", padx=10, pady=(5, 0))

        self.console_text = ctk.CTkTextbox(self.console_frame, font=("Consolas", 12))
        self.console_text.pack(fill="both", expand=True, padx=10, pady=5)
        self.console_text.configure(state="disabled")

        # Redirect stdout to our console box
        sys.stdout = ConsoleRedirector(self.console_text)
        sys.stderr = ConsoleRedirector(self.console_text)

        # Initial checks
        self.check_dependencies_gui()

    def check_dependencies_gui(self):
        """Checks dependencies and logs to GUI console."""
        print("--- System Check ---")
        if not shutil.which('ffmpeg'):
            print("CRITICAL ERROR: FFmpeg not found!")
            print("Please install FFmpeg and restart the app.")
            messagebox.showerror("Error", "FFmpeg is missing! Audio conversion will fail.")
        else:
            print("FFmpeg detected successfully.")
            print("Ready to download.")

    def browse_folder(self):
        folder_selected = filedialog.askdirectory()
        if folder_selected:
            self.entry_folder.delete(0, "end")
            self.entry_folder.insert(0, folder_selected)

    def start_download_thread(self):
        """Starts the download in a separate thread to keep UI responsive."""
        url = self.entry_url.get().strip()
        folder = self.entry_folder.get().strip()

        if not url:
            messagebox.showwarning("Input Error", "Please enter a valid YouTube URL.")
            return

        # Disable button to prevent spam
        self.btn_download.configure(state="disabled", text="Downloading...")
        self.progress_bar.set(0)
        
        # Start thread
        threading.Thread(target=self.run_download, args=(url, folder), daemon=True).start()

    def progress_hook(self, d):
        """Hook for yt-dlp to update progress bar."""
        if d['status'] == 'downloading':
            try:
                # Calculate progress 0.0 to 1.0
                p = d.get('_percent_str', '0%').replace('%','')
                progress = float(p) / 100
                self.progress_bar.set(progress)
            except:
                pass
        elif d['status'] == 'finished':
            self.progress_bar.set(1)
            print("\nDownload complete. Processing audio...")

    def run_download(self, video_url, output_folder):
        """The actual download logic running in the background."""
        try:
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)

            print(f"\nInitialized download for: {video_url}")
            
            ydl_opts = {
                'format': 'bestaudio/best',
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '320',
                }],
                'outtmpl': os.path.join(output_folder, '%(title)s.%(ext)s'),
                'verbose': True,
                'progress_hooks': [self.progress_hook], # Add hook for progress bar
                'noplaylist': True,
            }

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([video_url])

            print(f"SUCCESS: Saved to {output_folder}")
            self.after(0, lambda: messagebox.showinfo("Success", "Download Completed Successfully!"))

        except Exception as e:
            print(f"ERROR: {e}")
            self.after(0, lambda: messagebox.showerror("Error", f"An error occurred:\n{e}"))
        
        finally:
            # Re-enable button
            self.after(0, lambda: self.btn_download.configure(state="normal", text="Start Download"))

if __name__ == "__main__":
    app = MusicDownloaderApp()
    app.mainloop()

